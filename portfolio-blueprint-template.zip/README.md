# Portfolio Blueprint — Guide de personnalisation

Merci d'avoir choisi ce template ! Voici comment le rendre 100% à ton image, sans connaissances techniques poussées.

## 1. Ce qu'il y a dans le dossier

- `index.html` — la structure et le contenu de ton site
- `style.css` — les couleurs, polices, mise en page
- `script.js` — les animations (menu mobile, apparitions au scroll) — tu n'as normalement rien à y toucher

## 2. Comment personnaliser le contenu

Ouvre `index.html` avec un éditeur de texte simple (Bloc-notes, ou idéalement [VS Code](https://code.visualstudio.com/), gratuit).

Tous les éléments à remplacer sont écrits entre crochets, par exemple :
```
[Ton prénom]
```
Remplace tout le texte entre crochets (crochets compris) par tes propres informations. Utilise Ctrl+F pour naviguer rapidement entre chaque `[...]`.

**Sections à remplir dans l'ordre :**
1. `<title>` et balises `<meta>` en haut du fichier (lignes 6-18) — le titre qui s'affiche dans l'onglet du navigateur et sur les réseaux sociaux
2. Le logo dans le header (`XX.`) — mets tes initiales
3. Hero — ton nom, titre, description, liens GitHub/LinkedIn
4. Profil — tes deux paragraphes de présentation + la fiche technique
5. Compétences — remplace les `[Compétence]` et ajuste les pourcentages (`--w:XX%`) selon ton niveau réel
6. Certifications — un bloc `.cert-row` par certification (duplique le bloc si tu en as plus)
7. Projet — ton projet phare, avec rôle, contribution, lien
8. Feuille de route — tes étapes d'apprentissage ou d'évolution professionnelle
9. Contact — email, GitHub, LinkedIn
10. Footer — ton nom en bas de page

## 3. Ajuster les couleurs (optionnel)

Dans `style.css`, tout en haut, tu trouveras un bloc `:root` avec les couleurs principales :

```css
--navy-1: #0B1826;   /* couleur de fond principale */
--accent: #FF7A45;   /* couleur d'accent (boutons, highlights) */
--cyan: #5EC8E8;     /* couleur secondaire */
```

Change juste les codes couleur (format `#RRGGBB`) si tu veux une autre ambiance — tout le reste s'adapte automatiquement.

## 4. Mettre ton site en ligne gratuitement (GitHub Pages)

1. Crée un compte sur [github.com](https://github.com) si tu n'en as pas
2. Crée un nouveau dépôt nommé exactement `ton-pseudo.github.io`
3. Upload les 3 fichiers (`index.html`, `style.css`, `script.js`) à la racine du dépôt
4. Va dans Settings > Pages, choisis la branche `main` et le dossier `/ (root)`, sauvegarde
5. Ton site est en ligne en 1-2 minutes à `https://ton-pseudo.github.io`

## 5. Sections optionnelles

- Si tu n'as pas encore de certifications, tu peux supprimer toute la section `<!-- ===== CERTIFICATIONS ===== -->` — pense à retirer aussi son lien dans le menu (`<a href="#certifications">`) et à renuméroter les sections suivantes (§ 04 devient § 03, etc.)
- Le bloc `.other-deliverable` sous le projet principal est optionnel — retire-le si tu n'as qu'un seul projet à présenter

## Besoin d'aide ?

Si tu bloques sur une étape, n'hésite pas à me contacter directement.

Bonne personnalisation !
